@extends('frontend.layouts.layout')
@section('aboutUs','menu__item--current')
@section('body')

<!--about strat here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>About Us</h2>
			</div>
			<div class="about-bottom">
				<div class="col-md-6 about-left">
					<h4>Duis aute irure dolor in reprehenderit in voluptate.</h4>
					<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born In a free hour, when our power.</p>
				</div>
				<div class="col-md-6 about-right">
					<img src="{{url('frontend/images/ab.jpg')}}" width="100%" height="400px" alt="" class="img-responsive">
				</div>
			   <div class="clearfix"> </div>
			</div>
		</div>
	</div>
</div>
<!--about end here-->
<div class="history">
	<div class="container">
		<div class="history-main">
	 	<div class="history-top">
	 	    <h3>Our History</h3>
	    </div>
	    <div class="history-bottom">
	    	<div class="col-md-4 history-grids">
	    		<h4>2015</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	    	<div class="col-md-4 history-grids">
	    		<h4>2014</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	    	<div class="col-md-4 history-grids">
	    		<h4>2013</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	    	<div class="clearfix"> </div>
	    </div>
	    <div class="history-bottom">
	    	<div class="col-md-4 history-grids">
	    		<h4>2012</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	    	<div class="col-md-4 history-grids">
	    		<h4>2011</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	    	<div class="col-md-4 history-grids">
	    		<h4>2009</h4>
	    		<p>Integer rutrum ante eu lacuestibulum libero nisl porta vel scelerisque eget malesuada at neque Vivamus eget nibh etiamursus leo.</p>
	    	</div>
	      <div class="clearfix"> </div>
	    </div>
	 </div>
   </div>
</div>
<!--team start here-->
<div class="">
	<div class="container">
		<div class="team-main">
             <div class="team-head">
             	<h3>Our Managment</h3>          	
             </div>
             <div class="team-bottom">
             	<!-- experts -->
				<div class="team-agileits">
						<div class="col-md-3 team-agileits-grid">
							<div class="btm-right">
								<img src="{{url('frontend/images/t1.jpg')}}" alt=" ">
									<div class="captn">
										<h4>John Doe</h4>
										<ul class="team-icons">
											<li><a class="fa" href="#"> </a></li>
											<li><a class="tw" href="#"> </a></li>
											<li><a class="g" href="#"> </a></li>
										</ul>
									</div>
							</div>
						</div>
						<div class="col-md-3 team-agileits-grid">
							<div class="btm-right">
								<img src="{{url('frontend/images/t2.jpg')}}" alt=" ">
									<div class="captn">
										<h4>Mary</h4>
										<ul class="team-icons">
											<li><a class="fa" href="#"> </a></li>
											<li><a class="tw" href="#"> </a></li>
											<li><a class="g" href="#"> </a></li>
										</ul>
									</div>
							</div>
						</div>
						<div class="col-md-3 team-agileits-grid">
							<div class="btm-right">
								<img src="{{url('frontend/images/t3.jpg')}}" alt=" ">
									<div class="captn">
										<h4>Katerina</h4>
										<ul class="team-icons">
											<li><a class="fa" href="#"> </a></li>
											<li><a class="tw" href="#"> </a></li>
											<li><a class="g" href="#"> </a></li>
										</ul>	
									</div>
							</div>
						</div>
						<div class="col-md-3 team-agileits-grid">
							<div class="btm-right">
								<img src="{{url('frontend/images/t4.jpg')}}" alt=" ">
									<div class="captn">
										<h4>Jenny</h4>
										<ul class="team-icons">
											<li><a class="fa" href="#"> </a></li>
											<li><a class="tw" href="#"> </a></li>
											<li><a class="g" href="#"> </a></li>
										</ul>
									</div>
							</div>
						</div>
						<div class="clearfix"> </div>
				</div>
				<!-- //experts -->
             </div>
		</div>
	</div>
</div>
<div><br><br></div>
<!--team end here-->

@endsection